# Self-Healing Infrastructure on AWS (Auto Scaling + Terraform)

This project provisions a **highly-available, self-healing** web tier on AWS using:
- **VPC** with two public subnets (multi-AZ)
- **Application Load Balancer (ALB)** with health checks on `/healthz`
- **Auto Scaling Group (ASG)** using a Launch Template
- **Target tracking scaling policy** on average CPU (50% target)

> Default region: `ap-south-1` (Mumbai). You can change it in `variables.tf` or via `-var` flags.

## Prerequisites
- **Terraform** v1.6+
- **AWS CLI** configured: `aws configure` (use an IAM user, not root)
- A default **VPC CIDR** and two subnet CIDRs that don't clash with your environment (defaults are fine for a demo).

## Quickstart
```bash
# 1) Extract and enter the folder
unzip self-healing-infra.zip -d ./
cd self-healing-infra

# 2) Initialize Terraform
terraform init

# 3) Review the execution plan
terraform plan -out tf.plan

# 4) Create the infrastructure
terraform apply tf.plan
```

## What gets created
- **VPC**: 10.0.0.0/16, two public subnets across AZs
- **Security Groups**:
  - `alb_sg`: inbound 80 from anywhere
  - `ec2_sg`: inbound 80 from ALB only
- **ALB** (HTTP 80) -> **Target Group** (HTTP, health check path `/healthz`)
- **ASG** of EC2 instances (Amazon Linux 2023) behind ALB
- **User Data** installs Nginx and serves `/` and `/healthz`
- **Auto Scaling Policy**: Target tracking at 50% ASG average CPU

## Testing
1. Get the ALB DNS from Terraform output:
   ```bash
   terraform output alb_dns_name
   ```
2. Hit the health endpoint:
   ```bash
   curl http://$(terraform output -raw alb_dns_name)/healthz
   ```
   You should see: `OK`

## Demonstrate Self-Healing
- In the AWS console, **terminate one EC2 instance** in the ASG.
- The ASG will **automatically launch a replacement** instance.
- The ALB will **stop routing** to the unhealthy instance and resume when the new one passes health checks.

## Tuning
- Change `target_cpu_utilization` to a different value (e.g., 60) in `variables.tf`.
- Adjust `min_size`, `max_size`, `desired_capacity` to fit your cost/perf needs.
- For production: move instances to **private subnets** with NAT, enable **HTTPS (ACM)** on ALB, add **CloudWatch dashboards/alarms**, manage **state backend** (S3 + DynamoDB).

## Cleanup
```bash
terraform destroy -auto-approve
```

## Notes
- This demo uses **public subnets** for simplicity.
- No SSH is opened by default. If you need SSH, add a rule restricted to your IP and use SSM Session Manager for safer access.

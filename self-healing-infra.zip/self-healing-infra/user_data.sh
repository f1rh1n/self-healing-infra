#!/bin/bash
# Update & install nginx
dnf -y update
dnf -y install nginx

# Simple web page
cat > /usr/share/nginx/html/index.html << 'EOF'
<html>
  <head><title>Self-Healing Demo</title></head>
  <body>
    <h1>It works! 🚀</h1>
    <p>This instance is behind an ALB and managed by an Auto Scaling Group.</p>
  </body>
</html>
EOF

# Health endpoint
echo "OK" > /usr/share/nginx/html/healthz

# Start & enable nginx
systemctl enable nginx
systemctl start nginx
